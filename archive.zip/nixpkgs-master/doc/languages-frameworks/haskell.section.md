# Haskell {#haskell}

The documentation for the Haskell infrastructure is published at
<https://haskell4nix.readthedocs.io/>. The source code for that
site lives in the `doc/` sub-directory of the
[`cabal2nix` Git repository](https://github.com/NixOS/cabal2nix)
and changes can be submitted there.
