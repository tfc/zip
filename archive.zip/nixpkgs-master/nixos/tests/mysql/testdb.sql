create table tests
( Id   INTEGER      NOT NULL,
  Name VARCHAR(255) NOT NULL,
  primary key(Id)
);

insert into tests values (1, 'a');
insert into tests values (2, 'b');
insert into tests values (3, 'c');
insert into tests values (4, 'd');
insert into tests values (5, 'hello');
