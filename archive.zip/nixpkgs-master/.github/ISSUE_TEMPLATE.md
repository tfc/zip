## Issue description



### Steps to reproduce



## Technical details

Please run `nix-shell -p nix-info --run "nix-info -m"` and paste the result.
